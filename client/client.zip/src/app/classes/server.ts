import {Message} from "./message";

export class Server
{
  private _ip: string;
  private _ws: WebSocket | null;
  private _port:Number;

  constructor( ws: WebSocket , ip: string , port: Number = -1 )
  {
    this._ip = ip;
    this._ws = ws;
    this._port = port;
  }

  get ip(): string
  {
    return this._ip;
  }

  public static connect( ip: string , port: Number ): Server
  {
    let ws: WebSocket = new WebSocket( "ws://" + ip + (port == -1 ? "" : (":" + port.toFixed(0))) );
    let retval = new Server( ws , ip , port );
    ws.onerror = (ev => {
      console.log( "failed" );
      retval.disconnect();
    });
    ws.onclose = (ev => {
      console.log( "error" );
      retval.disconnect();
    });
    ws.onmessage = (ev => {
      console.log( ev );
    });
    return retval;
  }

  public send( message: Message ): boolean
  {
    if ( this._ws === null )
      return false;
    if ( this._ws.readyState == 1 )
    {
      this._ws.send( JSON.stringify( message ) );
      return true;
    }
    return false;
  }

  public disconnect(): void
  {
    if ( this._ws !== null )
      this._ws.close();
    this._ws = null;
  }

  public get connected(): boolean
  {
    return this._ws !== null;
  }
}
