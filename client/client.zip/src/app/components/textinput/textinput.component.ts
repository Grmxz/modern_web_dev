import {Component , OnInit } from '@angular/core';
import {StatusService} from "../../services/status.service";
import {Message} from "../../classes/message";

@Component( {
  selector: 'app-textinput' ,
  templateUrl: './textinput.component.html' ,
  styleUrls: ['./textinput.component.css']
} )
export class TextinputComponent implements OnInit
{
  public ip!: string;
  public message!: string;
  public recipient!: string;


  constructor( public status: StatusService )
  {
  }

  ngOnInit(): void
  {
  }

  public connect(): void
  {
    console.log( "connect to : " + this.ip );
    this.status.connect( this.ip , "" );
  }

  public send(): void
  {
    console.log( "send '" + this.message + "' to : " + this.recipient );
    console.log( this.status.send( new Message( this.status.loggedInUser , this.recipient , this.message , false ) ) );
  }
}
